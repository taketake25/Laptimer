#include "mbed.h"
#define addr 0x40 //自身のアドレス

/*

プルアップ抵抗を忘れないこと!!
異なる電圧間では、電圧レベル変換モジュールを推奨!!

*/

I2CSlave slave(D14,D15); //SDA SCL Nucleo
DigitalOut led(D2);
AnalogIn sen1(A0);
AnalogIn sen2(A1);
//I2CSlave slave(dp5,dp27); //SDA SCL LPC1114FN
//DigitalOut led(dp14);

int main() {
    char buf[10]={0}; //受信用バッファ
    char ret[10]={0}; //送信用バッファ
    int i=0;
    int count = 0;
    float val;

/*    for(int j=0;j<4;j++){   
        led=!led; wait(0.2);
    }*/

    printf("slave start\r\n");
    slave.frequency(100000); //通信の速度を指定
    slave.address(addr); //自身のアドレスを登録

//    while(1)printf("%f\r\n",(float)sen2.read());
    while(1){
        i = slave.receive();
        if(i==I2CSlave::ReadAddressed){//Masterへの送信 ReadAddressed = 1
            switch(buf[0]){
            case 's':
                val = (float)sen1.read();
                if(val < 0.035)ret[0]=0;
                else ret[0]=1;
                break;
            case 'g':
                val = (float)sen1.read();
                if(val < 0.035)ret[0]=0;
                else ret[0]=1;
                break;
            }
//            printf("%c\r",ret[0]);
            slave.write(ret,1);

/*
            ret[0]=buf[5]; //さっき受信した文字列の6番目の値を格納(送信する一つ目の情報)
            ret[1]=(int)(buf[5]*3); //↑を2倍した値を格納(送信する二つ目の情報)
            ret[2]=(int)(buf[5]/3); //↑を1/2した値を格納(送信する三つ目の情報)
            slave.write(ret,3); //masterに3Byte送信
            //printf("slave writes:%d %d %d \r\n\r\n",ret[0],ret[1],ret[2]); //masterに送信した情報を10進数で表示
 
            for(int i=0;i<strlen(buf);i++)buf[i]='\0';//配列の初期化
*/
        }else if(i==I2CSlave::WriteAddressed){//Masterからの信号 WriteAddressed = 3
            slave.read(buf,1); //masterから6Byte受信
//            printf("%c ",buf[0]);
            //printf("slave reads:%s\r\n",buf); //bufの途中に'\0'があると、そこで表示が終わってしまう。
        }
    }
}
